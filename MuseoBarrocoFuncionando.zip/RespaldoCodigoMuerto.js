/*Script Museo de Pebla



*/

///[Load stylesheet]
$.app.addStyleFilename("style.css");
///[Load Stylessheet]
/// [Contenedores Principales]
var anchoPrincipal           = ($.app.mainLayer().width())/3;
var alturaPrincipal          = $.app.mainLayer().height();

//for (var i = 0; i <3; ++i) {
  /*****************/
   var cont_icon     = new MultiWidgets.Widget();
  var regresar      = new MultiWidgets.ImageWidget();
  var regresarText  = new MultiWidgets.TextWidget();
  var zoom          = new MultiWidgets.ImageWidget();
  var text_zoom     = new MultiWidgets.TextWidget();
  var exit          = new MultiWidgets.ImageWidget();
  /*****************/

var cajaPrincipalIzq       = new MultiWidgets.Widget();
var cajaPrincipalCentro    = new MultiWidgets.Widget();
var cajaPrincipalDer       = new MultiWidgets.Widget();

var ConsolaLog             = new MultiWidgets.TextWidget();

//[ En caso de agregar mas imagenes o mas informacion de la imagen, Se almacena en los dos areglos de abajo]
  // [*nota: la posicion debe de estar relacionado con su propia imagen 1 a 1 2 a 2]
  var URLImagenes    = ['IMG/img1.jpg', 'IMG/img2.jpg','IMG/img3.jpg'];
  var URLImagenes2    = ['IMG/image1.jpg', 'IMG/image2.jpg','IMG/image3.jpg'];
  var URLImagenes3    = ['IMG/images1.jpg', 'IMG/images2.jpg','IMG/images3.jpg'];


  var DataMostrar    = ['Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                        'Otra Inforacion mAs que los  Hace mas interesante Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                        'Una Prueba Mas y mas Aun mas'];


crearPantalla('PrincipalIzq',cajaPrincipalIzq, 0, 0, anchoPrincipal, alturaPrincipal);
crearPantalla('PrincipalCent',cajaPrincipalCentro, anchoPrincipal,0, anchoPrincipal, alturaPrincipal);
crearPantalla('PrincipalDer',cajaPrincipalDer, anchoPrincipal*2,0, anchoPrincipal, alturaPrincipal);


$.app.mainLayer().addChild(cajaPrincipalIzq);
$.app.mainLayer().addChild(cajaPrincipalCentro);
$.app.mainLayer().addChild(cajaPrincipalDer);

function crearPantalla(id, WidgetPantalla, posicionX, posicionY, TamanhoAncho, Altura){
  var cajaSecundaria         = new MultiWidgets.Widget();
  var cajaTouch              = new MultiWidgets.Widget();
  var imgDedo                = new MultiWidgets.ImageWidget();
  //var imgAmerica             = new MultiWidgets.Widget();


  WidgetPantalla.setCSSClasses('cajaPrincipal');
  WidgetPantalla.setCSSId(id);
  WidgetPantalla.setWidth(TamanhoAncho);
  WidgetPantalla.setHeight(Altura);
  WidgetPantalla.setLocation(posicionX, posicionY);

  cajaSecundaria.setCSSClasses('cajaSecundaria');
  cajaSecundaria.setCSSId('cajaTouch'+id);
  cajaSecundaria.setLocation(43,43);
  cajaSecundaria.setWidth(WidgetPantalla.width()-86);
  cajaSecundaria.setHeight(WidgetPantalla.height()-86);

  cajaTouch.setCSSClasses('cajaTouch');
  cajaTouch.setCSSId('cajaTouch'+id);
  cajaTouch.setLocation(0,0);
  cajaTouch.setWidth(cajaSecundaria.width());
  cajaTouch.setHeight(cajaSecundaria.height());

  //imgAmerica.setCSSClasses('imgAmerica');
  //imgAmerica.setCSSId('imgAmerica'+id);
  //imgAmerica.setLocation(0,0);
  //imgAmerica.setWidth(cajaSecundaria.width());
  //imgAmerica.setHeight(cajaSecundaria.height());

  imgDedo.setSource("IMG/layer1.png");
  imgDedo.setCSSId('imgDedo'+id);
  imgDedo.setLocation((cajaTouch.width()/2)-50,(cajaTouch.height()/2)-50);

  cajaTouch.addChild(imgDedo);
  cajaSecundaria.addChild(cajaTouch);
  WidgetPantalla.addChild(cajaSecundaria);
  cajaTouch.eventAddListener("single-tap", function () {

    cajaSecundaria.removeChild(cajaTouch);
    //cajaSecundaria.addChild(imgAmerica);
    crearSegundo('SegundaEscena', cajaSecundaria);
  });
}
function crearSegundo(id, cajaSecundaria){
    var imgAmerica        = new MultiWidgets.Widget();
    var texto             = new MultiWidgets.TextWidget();
    imgAmerica.setCSSClasses('imgAmerica');
    imgAmerica.setCSSId('imgAmerica'+id);
    imgAmerica.setLocation(0,0);
    imgAmerica.setWidth(cajaSecundaria.width());
    imgAmerica.setHeight(cajaSecundaria.height());

    texto.setCSSClasses('texto');
    texto.setCSSId('texto'+id);
    texto.setLocation(cajaSecundaria.width()/2-200,cajaSecundaria.height()/2-50);
    texto.setWidth(cajaSecundaria.width());
    texto.setHeight(200);
    texto.setText('BARROCO \n El primer arte que alcanzo \n a todo el mundo');

    imgAmerica.addChild(texto);
    cajaSecundaria.addChild(imgAmerica);

    imgAmerica.eventAddListener("single-tap", function () {
      texto.setLocation(cajaSecundaria.width()/2-200,0);
      CrearTercerEscenario(imgAmerica.width(),imgAmerica.height(), id, imgAmerica, cajaSecundaria);
      //cajaSecundaria.removeChild(imgAmerica);

    });
}
function CrearTercerEscenario(ancho, altura, id, imgAmerica,cajaSecundaria){
  var ctnImgen       = new MultiWidgets.Widget();
  var ctnImgenF1     = new MultiWidgets.Widget();
  var ctnImgenF2     = new MultiWidgets.Widget();
  var ctnImgenF3     = new MultiWidgets.Widget();

  

// [Contenedor]
  ctnImgen.setCSSClasses('ctnImgen');
  ctnImgen.setCSSId('ctnImgen'+id);
  ctnImgen.setLocation(0,imgAmerica.height()/4);
  ctnImgen.setWidth(imgAmerica.width());
  ctnImgen.setHeight((imgAmerica.height()/4)*3);
  // [Fila 1]

  ctnImgenF1.setCSSClasses('ctnImgenF1');
  ctnImgenF1.setCSSId('ctnImgenF1'+id);
  ctnImgenF1.setLocation(0,0);
  ctnImgenF1.setWidth(ctnImgen.width());
  ctnImgenF1.setHeight(ctnImgen.height()/3);
  // [Fila 2]

  ctnImgenF2.setCSSClasses('ctnImgenF2');
  ctnImgenF2.setCSSId('ctnImgenF2'+id);
  ctnImgenF2.setLocation(0,ctnImgen.height()/3);
  ctnImgenF2.setWidth(ctnImgen.width());
  ctnImgenF2.setHeight(ctnImgen.height()/3);
    // [Fila 2]

  ctnImgenF3.setCSSClasses('ctnImgenF3');
  ctnImgenF3.setCSSId('ctnImgenF3'+id);
  ctnImgenF3.setLocation(0,(ctnImgen.height()/3)*2);
  ctnImgenF3.setWidth(ctnImgen.width());
  ctnImgenF3.setHeight(ctnImgen.height()/3);

  //[Agregar Imagenes]
  for (var i = 0; i < URLImagenes.length ; i++) {
    AgregarImagenes('Imagen'+i, URLImagenes[i], DataMostrar[i], cajaSecundaria, imgAmerica, ctnImgenF1,i);
    AgregarImagenes('Imagen'+i, URLImagenes2[i], DataMostrar[i], cajaSecundaria, imgAmerica, ctnImgenF2,i);
    AgregarImagenes('Imagen'+i, URLImagenes3[i], DataMostrar[i], cajaSecundaria, imgAmerica, ctnImgenF3,i);
    
  }

  ctnImgen.addChild(ctnImgenF1);
  ctnImgen.addChild(ctnImgenF2);
  ctnImgen.addChild(ctnImgenF3);
  imgAmerica.addChild(ctnImgen);
}
///----------------------------------------------------
function AgregarImagenes(id, URlImg, informacion, cajaSecundaria, imgAmerica, ctnImgenF1, i){
  //[Se agrega las Imagenes del Interactivo]
    var Imagenes      = new MultiWidgets.ImageWidget();
    Imagenes.setSource(URlImg);
    Imagenes.setLocation((i*ctnImgenF1.width()/3),0);
    Imagenes.setWidth(ctnImgenF1.width()/3);
    Imagenes.setHeight(ctnImgenF1.height());
    ctnImgenF1.addChild(Imagenes);
    Imagenes.eventAddListener('single-tap', function(){
      cajaSecundaria.removeChild(imgAmerica);
      mostrarImgEInformacion(URlImg, informacion, cajaSecundaria, imgAmerica,i);
    });
}
function AgregarImagenes2(id, URlImg2, informacion, cajaSecundaria, imgAmerica, ctnImgenF1, i){
  //[Se agrega las Imagenes del Interactivo]
    var Imagenes      = new MultiWidgets.ImageWidget();
    Imagenes.setSource(URlImg2);
    Imagenes.setLocation((i*ctnImgenF1.width()/3),0);
    Imagenes.setWidth(ctnImgenF1.width()/3);
    Imagenes.setHeight(ctnImgenF1.height());
    ctnImgenF2.addChild(Imagenes);
    Imagenes.eventAddListener('single-tap', function(){
      cajaSecundaria.removeChild(imgAmerica);
      mostrarImgEInformacion(URlImg2, informacion, cajaSecundaria, imgAmerica,i);
    });
}
function AgregarImagenes3(id, URlImg3, informacion, cajaSecundaria, imgAmerica, ctnImgenF1, i){
  //[Se agrega las Imagenes del Interactivo]
    var Imagenes      = new MultiWidgets.ImageWidget();
    Imagenes.setSource(URlImg3);
    Imagenes.setLocation((i*ctnImgenF1.width()/3),0);
    Imagenes.setWidth(ctnImgenF1.width()/3);
    Imagenes.setHeight(ctnImgenF1.height());
    ctnImgenF3.addChild(Imagenes);
    Imagenes.eventAddListener('single-tap', function(){
      cajaSecundaria.removeChild(imgAmerica);
      mostrarImgEInformacion(URlImg3, informacion, cajaSecundaria, imgAmerica,i);
    });
}
//------------------------------------------------------------
function mostrarImgEInformacion(URlImg, informacion, cajaSecundaria, imgAmerica, i){
  var Imagen        = new MultiWidgets.ImageWidget();
  var cntInformar   = new MultiWidgets.Widget();
  var texto         = new MultiWidgets.TextWidget();
  var titulo        = new MultiWidgets.TextWidget();
  var subtitulo     = new MultiWidgets.TextWidget();

   var cntSiguiente  = new MultiWidgets.Widget();
  var imgSiguiente  = new MultiWidgets.ImageWidget();
  var textoSiguiente= new MultiWidgets.TextWidget();

  var altura        = cajaSecundaria.height();
  var anchura       = cajaSecundaria.width();
  Imagen.setSource(URlImg);
  Imagen.setLocation(0,0);
  Imagen.setWidth(imgAmerica.width()-30);
  Imagen.setHeight((altura/3)*2);

/*---------------------------------------------------------------------*/
  cont_icon.setCSSId('cont_icon');
  cont_icon.setWidth(Imagen.width());
  cont_icon.setHeight(Imagen.height()-460);
  cont_icon.setLocation(0,Imagen.height()-82);
  Imagen.addChild(cont_icon);

  regresarText.setCSSId('regresarText');
  regresarText.setLocation(cont_icon.width()-390,cont_icon.height()-50);
  regresarText.setText('Regresar');
  cont_icon.addChild(regresarText);

  regresar.setCSSId('regresar');
  regresar.setSource("IMG/regresar.png");
  regresar.setLocation(cont_icon.width()-410,cont_icon.height()-60);
  regresar.setWidth(cont_icon.width()-395);
  regresar.setHeight(cont_icon.height()-40);
  cont_icon.addChild(regresar);

  text_zoom.setCSSId('text_zoom');
  text_zoom.setLocation(cont_icon.width()-190,cont_icon.height()-50);
  text_zoom.setText('Puedes acercar la imagen presionando');
  text_zoom.setWidth(cont_icon.width()-270);
  text_zoom.setHeight(cont_icon.height()-40);
  cont_icon.addChild(text_zoom);

  zoom.setCSSId('zoom');
  zoom.setSource("IMG/icon.png");
  zoom.setLocation(cont_icon.width()-90,cont_icon.height()-60);
  zoom.setWidth(cont_icon.width()-305);
  zoom.setHeight(cont_icon.height()-20);
  cont_icon.addChild(zoom);

  exit.setCSSId('okram');
  exit.setSource("IMG/exit.png");
  exit.setLocation(Imagen.width()-70,Imagen.height()-530);
  exit.setWidth(Imagen.width()-390);
  exit.setHeight(Imagen.height()-500);
  exit.setVisible(false);
  Imagen.addChild(exit);

  regresarText.eventAddListener('single-tap',function(){
   Imagen.setVisible(false);
   cntInformar.setVisible(false);
  callScene(cajaSecundaria, imgAmerica,'SegundaEscena');
  });

  zoom.eventAddListener('single-tap', function(){
   modal(Imagen,imgAmerica);
   exit.setVisible(true);
  });

    exit.eventAddListener('single-tap', function(){
     Imagen.setLocation(0,0);
     Imagen.setWidth(imgAmerica.width()-30);
     Imagen.setHeight((altura/3)*2);
     exit.setVisible(false);
     mostrar_icons();
  });
/*--------------------------------------------------------------------*/

  cntInformar.setCSSClasses('cntInformar');
  cntInformar.setLocation(0, (altura/3)*2);
  cntInformar.setWidth(imgAmerica.width()-10);
  cntInformar.setHeight(altura/3);

  titulo.setText('Arcangel San Barriachel');
  titulo.setLocation(10,20);
  titulo.setCSSClasses('textoTitulo');
  titulo.setWidth(imgAmerica.width()-10);
  titulo.setPadding(10);

  subtitulo.setText('Bartolome Roman');
  subtitulo.setLocation(10, titulo.height()-30);
  subtitulo.setCSSClasses('textoSubtitulo');
  subtitulo.setWidth(imgAmerica.width()-10);
  subtitulo.setPadding(10);

  texto.setText(informacion);
  texto.setLocation(10,titulo.height()+subtitulo.height()-100);
  texto.setCSSClasses('textoInformacion');
  texto.setWidth(imgAmerica.width()-10);
  texto.setPadding(10);

  cntSiguiente.setLocation(cntInformar.width()-100, cntInformar.height()-100);
  cntSiguiente.setWidth(100);

  if(i>=URLImagenes.length){
    i=0;
  }
  imgSiguiente.setSource(URLImagenes[i+1]);
  imgSiguiente.setWidth(cntSiguiente.width()/1);
  imgSiguiente.setHeight(cntSiguiente.height());
  imgSiguiente.setLocation(0,0);

  textoSiguiente.setText('S I G U I E N T E \n Arcangel San Bartolome Roman');
  textoSiguiente.setWidth((cntSiguiente.width()/3)*2);
  textoSiguiente.setCSSClasses('textoSiguiente');
  textoSiguiente.setHeight(cntSiguiente.height());
  //textoSiguiente.setLocation();

//imgSiguiente  
//textoSiguiente
  cntSiguiente.addChild(imgSiguiente);

  cntInformar.addChild(cntSiguiente);
  cntInformar.addChild(texto);
  cntInformar.addChild(titulo);
  cntInformar.addChild(subtitulo);
  
  cajaSecundaria.addChild(cntInformar);
  cajaSecundaria.addChild(Imagen);
  imgSiguiente.eventAddListener('single-tap', function(){
    cajaSecundaria.removeChild(cntInformar);
    cajaSecundaria.removeChild(Imagen);
    mostrarImgEInformacion(URLImagenes[i+1], DataMostrar[i+1], cajaSecundaria, imgAmerica, i+1);
  });
}
/*---------------*/
function callScene(cajaSecundaria, imgAmerica,id)
{
  crearSegundo('SegundaEscena', cajaSecundaria);
 CrearTercerEscenario(imgAmerica.width(),imgAmerica.height(), id, imgAmerica, cajaSecundaria);


}
function modal(Imagen,imgAmerica){
   ocultar_icons(Imagen);
   Imagen.setWidth(imgAmerica.width()-30);
   Imagen.setHeight(imgAmerica.height());
   Imagen.setLocation(0,0);
}

function ocultar_icons(Imagen){
  regresarText.setVisible(false);
  text_zoom.setVisible(false);
  regresar.setVisible(false);
  zoom.setVisible(false);
}
function mostrar_icons(Imagen){
  regresarText.setVisible(true);
  text_zoom.setVisible(true);
  regresar.setVisible(true);
  zoom.setVisible(true);
}

/*-------------------------------*/

function mostrarImgEInformacion2(URlImg2, informacion, cajaSecundaria, imgAmerica, i){
  var Imagen        = new MultiWidgets.ImageWidget();
  var cntInformar   = new MultiWidgets.Widget();
  var texto         = new MultiWidgets.TextWidget();
  var titulo        = new MultiWidgets.TextWidget();
  var subtitulo     = new MultiWidgets.TextWidget();

  var cntSiguiente  = new MultiWidgets.Widget();
  var imgSiguiente  = new MultiWidgets.ImageWidget();
  var textoSiguiente= new MultiWidgets.TextWidget();

  var altura        = cajaSecundaria.height();
  var anchura       = cajaSecundaria.width();
  Imagen.setSource(URlImg2);
  Imagen.setLocation(0,0);
  Imagen.setWidth(imgAmerica.width()-10);
  Imagen.setHeight((altura/3)*2);

  cntInformar.setCSSClasses('cntInformar');
  cntInformar.setLocation(0, (altura/3)*2);
  cntInformar.setWidth(imgAmerica.width()-30);
  cntInformar.setHeight(altura/3);

  titulo.setText('Arcangel San Barriachel');
  titulo.setLocation(10,20);
  titulo.setCSSClasses('textoTitulo');
  titulo.setWidth(imgAmerica.width()-10);
  titulo.setPadding(10);

  subtitulo.setText('Bartolome Roman');
  subtitulo.setLocation(10, titulo.height()-30);
  subtitulo.setCSSClasses('textoSubtitulo');
  subtitulo.setWidth(imgAmerica.width()-10);
  subtitulo.setPadding(10);

  texto.setText(informacion);
  texto.setLocation(10,titulo.height()+subtitulo.height()-100);
  texto.setCSSClasses('textoInformacion');
  texto.setWidth(imgAmerica.width()-10);
  texto.setPadding(10);

  cntSiguiente.setLocation(cntInformar.width()-100, cntInformar.height()-100);
  cntSiguiente.setWidth(100);

  if(i>=URLImagenes.length){
    i=0;
  }
  imgSiguiente.setSource(URLImagenes[i+1]);
  imgSiguiente.setWidth(cntSiguiente.width()/1);
  imgSiguiente.setHeight(cntSiguiente.height());
  imgSiguiente.setLocation(0,0);

  textoSiguiente.setText('S I G U I E N T E \n Arcangel San Bartolome Roman');
  textoSiguiente.setWidth((cntSiguiente.width()/3)*2);
  textoSiguiente.setCSSClasses('textoSiguiente');
  textoSiguiente.setHeight(cntSiguiente.height());
  //textoSiguiente.setLocation();

//imgSiguiente  
//textoSiguiente
  cntSiguiente.addChild(imgSiguiente);

  cntInformar.addChild(cntSiguiente);
  cntInformar.addChild(texto);
  cntInformar.addChild(titulo);
  cntInformar.addChild(subtitulo);
  
  cajaSecundaria.addChild(cntInformar);
  cajaSecundaria.addChild(Imagen);
  imgSiguiente.eventAddListener('single-tap', function(){
    cajaSecundaria.removeChild(cntInformar);
    cajaSecundaria.removeChild(Imagen);
    mostrarImgEInformacion(URLImagenes[i+1], DataMostrar[i+1], cajaSecundaria, imgAmerica, i+1);
  });
}