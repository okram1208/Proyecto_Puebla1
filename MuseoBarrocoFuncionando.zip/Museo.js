/*Script Museo de Pebla

Nota: Importante: Estamos programando un sistema en lo cual son tres ventanas, lo cual cada elemente es diferente de cada una de ellas
Asi que si se va a ocupar un elemente que tenga su propia funcion, las variables que se van a declarar no seran globales, tienen que ser
locales para cada metodo Las unicas variables que seran globales, seran las URLImagenes Informacion. Solo ellos.

Nota 2: en caso de que un elemento se quiera usar mas tarde o en otra funcion pasa los elementos como parametro.

Nota: recuerda que esto son solo consejos. puedes agregar mas consejos abajo.

*****************************
*/

///[Cargar Hojas de Estilo]
// clases de Efectos

var Animacion               = new MultiWidgets.FadeAnimator();
$.app.addStyleFilename("style.css");
var capasBorderTop          = new MultiWidgets.Widget();
var capasBorderTop2          = new MultiWidgets.Widget();
var capasBorderTop3          = new MultiWidgets.Widget();
var capasBorderBottom       = new MultiWidgets.Widget();
var capasBorderBottom2       = new MultiWidgets.Widget();
var capasBorderBottom3       = new MultiWidgets.Widget();
/// [Valores de altura y anchura de la pantalla]
var anchoPrincipal           = ($.app.mainLayer().width())/3;
var alturaPrincipal          = $.app.mainLayer().height();
//{Widgets Principales}
var cajaPrincipalIzq       = new MultiWidgets.Widget();
var cajaPrincipalCentro    = new MultiWidgets.Widget();
var cajaPrincipalDer       = new MultiWidgets.Widget();

var ConsolaLog             = new MultiWidgets.TextWidget();

//[ En caso de agregar mas imagenes o mas informacion de la imagen, Se almacena en los dos areglos de abajo]
// [*nota: la posicion debe de estar relacionado con su propia imagen 1 a 1 2 a 2]
var URLImagenes    = ['IMG/img1.jpg', 'IMG/img2.jpg','IMG/img3.jpg', 'IMG/img1.jpg', 'IMG/img2.jpg','IMG/img3.jpg'];
var URLImagenes2    = ['IMG/image1.jpg', 'IMG/image2.jpg','IMG/image3.jpg', 'IMG/img1.jpg', 'IMG/img2.jpg','IMG/img3.jpg'];
var URLImagenes3    = ['IMG/images1.jpg', 'IMG/images2.jpg','IMG/images3.jpg', 'IMG/img1.jpg', 'IMG/img2.jpg','IMG/img3.jpg'];


var DataMostrar    = ['Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Otra Inforacion mAs que los  Hace mas interesante Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Una Prueba Mas y mas Aun mas',
                      'Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Otra Inforacion mAs que los  Hace mas interesante Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Una Prueba Mas y mas Aun mas',
                      'Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Otra Inforacion mAs que los  Hace mas interesante Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Una Prueba Mas y mas Aun mas',
                      'Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Otra Inforacion mAs que los  Hace mas interesante Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Una Prueba Mas y mas Aun mas',
                      'Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Otra Inforacion mAs que los  Hace mas interesante Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Una Prueba Mas y mas Aun mas',
                      'Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Otra Inforacion mAs que los  Hace mas interesante Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin Es una Obra de Arte Realizada En Cierto Tiempo En fin',
                      'Una Prueba Mas y mas Aun mas',
                      'Texto'];


crearPantalla('PrincipalIzq',cajaPrincipalIzq, 0, 0, anchoPrincipal, alturaPrincipal);
crearPantalla('PrincipalCent',cajaPrincipalCentro, anchoPrincipal,0, anchoPrincipal, alturaPrincipal);
crearPantalla('PrincipalDer',cajaPrincipalDer, anchoPrincipal*2,0, anchoPrincipal, alturaPrincipal);
/*------------------Border Top------------------*/
capasBorderTop.setCSSClasses('capasBorderTop');
capasBorderTop.setDepth(100);
capasBorderTop.setSize(anchoPrincipal-27,43);
capasBorderTop.setFixed();

capasBorderTop2.setCSSClasses('capasBorderTop');

capasBorderTop2.setDepth(100);
capasBorderTop2.setSize(anchoPrincipal-27,43);
capasBorderTop2.setLocation(anchoPrincipal,0);
capasBorderTop2.setFixed();

capasBorderTop3.setCSSClasses('capasBorderTop');
capasBorderTop3.setDepth(100);
capasBorderTop3.setSize(anchoPrincipal-27,43);
capasBorderTop3.setLocation(anchoPrincipal*2,0);
capasBorderTop3.setFixed();
/*------------------Border Button------------------*/
capasBorderBottom.setCSSClasses('capasBorderButtom');
capasBorderBottom.setDepth(100);
capasBorderBottom.setSize(anchoPrincipal-27,alturaPrincipal-43);
capasBorderBottom.setLocation(0,alturaPrincipal-43);
capasBorderBottom.setFixed();

capasBorderBottom2.setCSSClasses('capasBorderButtom');
capasBorderBottom2.setDepth(100);
capasBorderBottom2.setSize(anchoPrincipal-27,alturaPrincipal-43);
capasBorderBottom2.setLocation(anchoPrincipal,alturaPrincipal-43);
capasBorderBottom2.setFixed();

capasBorderBottom3.setCSSClasses('capasBorderButtom');
capasBorderBottom3.setDepth(100);
capasBorderBottom3.setSize(anchoPrincipal-27,alturaPrincipal-43);
capasBorderBottom3.setLocation(anchoPrincipal*2,alturaPrincipal-43);
capasBorderBottom3.setFixed();
//{Las pantallas se agregan Automaticament}
$.app.mainLayer().addChild(cajaPrincipalIzq);
$.app.mainLayer().addChild(cajaPrincipalCentro);
$.app.mainLayer().addChild(cajaPrincipalDer);

$.app.mainLayer().addChild(capasBorderTop);
$.app.mainLayer().addChild(capasBorderTop2);
$.app.mainLayer().addChild(capasBorderTop3);

$.app.mainLayer().addChild(capasBorderBottom);
$.app.mainLayer().addChild(capasBorderBottom2);
$.app.mainLayer().addChild(capasBorderBottom3);


//{se crea las pantallas}
function crearPantalla(id, WidgetPantalla, posicionX, posicionY, TamanhoAncho, Altura){
  var cajaSecundaria         = new MultiWidgets.Widget();
  var cajaTouch              = new MultiWidgets.Widget();
  var imgDedo                = new MultiWidgets.ImageWidget();

  WidgetPantalla.setCSSClasses('cajaPrincipal');
  WidgetPantalla.setCSSId(id);
  WidgetPantalla.setWidth(TamanhoAncho);
  WidgetPantalla.setHeight(Altura);
  WidgetPantalla.setLocation(posicionX, posicionY);

  cajaSecundaria.setCSSClasses('cajaSecundaria');
  cajaSecundaria.setCSSId('cajaTouch'+id);
  cajaSecundaria.setLocation(43,43);
  cajaSecundaria.setWidth(WidgetPantalla.width()-86);
  cajaSecundaria.setHeight(WidgetPantalla.height()-86);

  cajaTouch.setCSSClasses('cajaTouch');
  cajaTouch.setCSSId('cajaTouch'+id);
  cajaTouch.setLocation(0,0);
  cajaTouch.setWidth(cajaSecundaria.width());
  cajaTouch.setHeight(cajaSecundaria.height());


  imgDedo.setSource("IMG/layer1.png");
  imgDedo.setCSSId('imgDedo'+id);
  imgDedo.setLocation((cajaTouch.width()/2)-50,(cajaTouch.height()/2)-50);

  cajaTouch.addChild(imgDedo);
  cajaSecundaria.addChild(cajaTouch);
  WidgetPantalla.addChild(cajaSecundaria);
  cajaTouch.eventAddListener("single-tap", function () {
    //Animacion.FadeOut(cajaTouch,3, 0.0);
    MultiWidgets.FadeAnimator.fadeOutAndDelete(cajaTouch, 1.0, 0.0);
    //cajaSecundaria.removeChild(cajaTouch);
    crearSegundo('SegundaEscena', cajaSecundaria);
  });
}
//{Funcion: Se crea Segundo Escenario}
function crearSegundo(id, cajaSecundaria){
    var imgAmerica        = new MultiWidgets.Widget();
    var texto             = new MultiWidgets.TextWidget();
    imgAmerica.setCSSClasses('imgAmerica');
    imgAmerica.setCSSId('imgAmerica'+id);
    imgAmerica.setLocation(0,0);
    imgAmerica.setWidth(cajaSecundaria.width());
    imgAmerica.setHeight(cajaSecundaria.height());

    texto.setCSSClasses('texto');
    texto.setCSSId('texto'+id);
    texto.setLocation(cajaSecundaria.width()/2-200,cajaSecundaria.height()/2-50);
    texto.setWidth(cajaSecundaria.width());
    texto.setHeight(200);
    texto.setText('BARROCO \n El primer arte que alcanzo \n a todo el mundo');

    imgAmerica.addChild(texto);
    cajaSecundaria.addChild(imgAmerica);
    imgAmerica.setVisible(false);
    MultiWidgets.FadeAnimator.fadeIn(imgAmerica, 2.0, 0.0);


    imgAmerica.eventAddListener("single-tap", function () {
      texto.setLocation(cajaSecundaria.width()/2-200,0);
      CrearTercerEscenario(imgAmerica.width(),imgAmerica.height(), id, imgAmerica, cajaSecundaria);

    });
}
//{Crea Todas, el Tercer Escenario y ademas agrega todas imagenes en su y su respectivo posicion}
function CrearTercerEscenario(ancho, altura, id, imgAmerica,cajaSecundaria){
  var ctnImgen       = new MultiWidgets.Widget();
  var ctnImgenF1     = new MultiWidgets.Widget();
  var ctnImgenF2     = new MultiWidgets.Widget();
  var ctnImgenF3     = new MultiWidgets.Widget();
  //var Scroll         = new MultiWidgets.ScrollAreaWidget();

  //Scroll.setScroll();
  

  // [Contenedor]
  ctnImgen.setCSSClasses('ctnImgen');
  ctnImgen.setCSSId('ctnImgen'+id);
  ctnImgen.setLocation(0,0);
  ctnImgen.setWidth(imgAmerica.width());
  ctnImgen.setHeight(imgAmerica.height());
  //ctnImgen.setOverFlow)
  // [Fila 1]

  ctnImgenF1.setCSSClasses('ctnImgenTop');
  ctnImgenF1.setCSSId('ctnImgen'+id);
  ctnImgenF1.setLocation(0,0);
  ctnImgenF1.setWidth(ctnImgen.width()/3);
  ctnImgenF1.setHeight(ctnImgen.height());
  ctnImgenF1.setCSSType("ScrollOperator");
  // [Fila 2]

  ctnImgenF2.setCSSClasses('ctnImgenCenter');
  ctnImgenF2.setCSSId('ctnImgen'+id);
  ctnImgenF2.setLocation(ctnImgen.width()/3,0);
  ctnImgenF2.setWidth(ctnImgen.width()/3);
  ctnImgenF2.setHeight(ctnImgen.height());
    // [Fila 2]

  ctnImgenF3.setCSSClasses('ctnImgenBottom');
  ctnImgenF3.setCSSId('ctnImgen'+id);
  ctnImgenF3.setLocation((ctnImgen.width()/3)*2,0);
  ctnImgenF3.setWidth(ctnImgen.width()/3);
  ctnImgenF3.setHeight(ctnImgen.height());

  //[Agregar Imagenes]
  for (var i = 0; i < URLImagenes.length ; i++) {
    AgregarImagenes('Imagen'+i, URLImagenes[i], DataMostrar[i], cajaSecundaria, imgAmerica, ctnImgenF1,i);
    AgregarImagenes('Imagen'+i, URLImagenes2[i], DataMostrar[i], cajaSecundaria, imgAmerica, ctnImgenF2,i);
    AgregarImagenes('Imagen'+i, URLImagenes3[i], DataMostrar[i], cajaSecundaria, imgAmerica, ctnImgenF3,i);
    
  }

  ctnImgen.addChild(ctnImgenF1);
  ctnImgen.addChild(ctnImgenF2);
  ctnImgen.addChild(ctnImgenF3);
  imgAmerica.addChild(ctnImgen);
  ctnImgenF1.addOperator(create(0,'derecha'));
  ctnImgenF2.addOperator(create((ctnImgen.width()/3)*1,'izquierda'));
  ctnImgenF3.addOperator(create((ctnImgen.width()/3)*2,'derecha'));
}
//{Funcion: agregar las imagenes en su respectivo contenedor}
function AgregarImagenes(id, URlImg, informacion, cajaSecundaria, imgAmerica, ctnImgenF1, i){
  //[Se agrega las Imagenes del Interactivo]
    var Imagenes      = new MultiWidgets.ImageWidget();
    Imagenes.setSource(URlImg);
    Imagenes.setLocation(0,i*ctnImgenF1.height()/4);
    Imagenes.setWidth(ctnImgenF1.width());
    Imagenes.setHeight(ctnImgenF1.height()/3);
    ctnImgenF1.addChild(Imagenes);
    Imagenes.eventAddListener('single-tap', function(){
      cajaSecundaria.removeChild(imgAmerica);
      mostrarImgEInformacion(id, URlImg, informacion, cajaSecundaria, imgAmerica,i);
    });
    //Imagenes.addOperator(create(0,'derecha'));
}

//{Funcion: Se muestra la Imagen con su respectivo Informacion, asi como su proximo Imagen}
function mostrarImgEInformacion(id, URlImg, informacion, cajaSecundaria, imgAmerica, i){
  var Imagen        = new MultiWidgets.ImageWidget();
  var cntInformar   = new MultiWidgets.Widget();
  var texto         = new MultiWidgets.TextWidget();
  var titulo        = new MultiWidgets.TextWidget();
  var subtitulo     = new MultiWidgets.TextWidget();

  var cntSiguiente  = new MultiWidgets.Widget();
  var imgSiguiente  = new MultiWidgets.ImageWidget();
  var textoSiguiente= new MultiWidgets.TextWidget();

  var cont_icon     = new MultiWidgets.Widget();
  var regresar      = new MultiWidgets.ImageWidget();
  var regresarText  = new MultiWidgets.TextWidget();
  var zoom          = new MultiWidgets.ImageWidget();
  var text_zoom     = new MultiWidgets.TextWidget();
  var exit          = new MultiWidgets.ImageWidget();

  var altura        = cajaSecundaria.height();
  var anchura       = cajaSecundaria.width();

  var Cont_Span     = new MultiWidgets.Widget();
  var españa        = new MultiWidgets.ImageWidget();
  var text_span     = new MultiWidgets.TextWidget();

  var fondo_Sig     = new MultiWidgets.Widget();
  var text_Sig      = new MultiWidgets.TextWidget()

  Imagen.setSource(URlImg);
  Imagen.setLocation(0,0);
  Imagen.setWidth(imgAmerica.width()-30);
  Imagen.setHeight((altura/3)*2);

  cont_icon.setCSSId('cont_icon');
  cont_icon.setWidth(Imagen.width());
  cont_icon.setHeight(Imagen.height()-460);
  cont_icon.setLocation(0,Imagen.height()-82);
  Imagen.addChild(cont_icon);

  regresarText.setCSSId('regresarText');
  regresarText.setLocation(cont_icon.width()-390,cont_icon.height()-50);
  regresarText.setText('Regresar');
  cont_icon.addChild(regresarText);

  regresar.setCSSId('regresar');
  regresar.setSource("IMG/regresar.png");
  regresar.setLocation(cont_icon.width()-410,cont_icon.height()-60);
  regresar.setWidth(cont_icon.width()-395);
  regresar.setHeight(cont_icon.height()-40);
  cont_icon.addChild(regresar);

  text_zoom.setCSSId('text_zoom');
  text_zoom.setLocation(cont_icon.width()-190,cont_icon.height()-50);
  text_zoom.setText('Puedes acercar la imagen presionando');
  text_zoom.setWidth(cont_icon.width()-270);
  text_zoom.setHeight(cont_icon.height()-40);
  cont_icon.addChild(text_zoom);

  zoom.setCSSId('zoom');
  zoom.setSource("IMG/icon.png");
  zoom.setLocation(cont_icon.width()-90,cont_icon.height()-60);
  zoom.setWidth(cont_icon.width()-305);
  zoom.setHeight(cont_icon.height()-20);
  cont_icon.addChild(zoom);
 //{Diseño de Salir ventana}
  exit.setCSSId('exit');
  exit.setSource("IMG/exit.png");
  exit.setLocation(Imagen.width()-70,Imagen.height()-530);
  exit.setWidth(Imagen.width()-390);
  exit.setHeight(Imagen.height()-500);
  exit.setVisible(false);
  Imagen.addChild(exit);

  cntInformar.setCSSClasses('cntInformar');
  cntInformar.setLocation(0, (altura/3)*2);
  cntInformar.setWidth(imgAmerica.width()-30);
  cntInformar.setHeight(altura/3);

  

  text_span.setCSSId('text_span');
  text_span.setText("España");
    españa.setWidth(60);
  españa.setHeight(60);
  text_span.setLocation(12,57);

  titulo.setText('Arcangel San Barriachel');
  titulo.setLocation(10,20);
  titulo.setCSSClasses('textoTitulo');
  titulo.setWidth(imgAmerica.width()-10);
  titulo.setPadding(10);

  subtitulo.setText('Bartolome Roman');
  subtitulo.setLocation(10, titulo.height()-30);
  subtitulo.setCSSClasses('textoSubtitulo');
  subtitulo.setWidth(imgAmerica.width()-10);
  subtitulo.setPadding(10);

  texto.setText(informacion);
  texto.setLocation(10,titulo.height()+subtitulo.height()-100);
  texto.setCSSClasses('textoInformacion');
  texto.setWidth(imgAmerica.width()-80);
  texto.setWidth(imgAmerica.height()-80);
  texto.setSize(cntInformar.width(),70);
  texto.setPadding(10);


  cntSiguiente.setLocation(cntInformar.width()-100, cntInformar.height()-100);
  cntSiguiente.setWidth(100);

  fondo_Sig.setCSSId('fondo_Sig');
  fondo_Sig.setWidth(205);
  fondo_Sig.setHeight(100);
  fondo_Sig.setLocation(0,0);

  if (i+1<URLImagenes.length) {
    imgSiguiente.setSource('IMG/sig.png');
    imgSiguiente.setCSSId('imgSiguiente');
    imgSiguiente.setWidth(cntInformar.width()-180);
    imgSiguiente.setHeight(cntSiguiente.height());
    imgSiguiente.setLocation(cntInformar.width()-237,172);
  }

  textoSiguiente.setText('S I G U I E N T E \n Arcangel San Bartolome Roman');
  textoSiguiente.setWidth((cntSiguiente.width()/3)*2);
  textoSiguiente.setCSSClasses('textoSiguiente');
  textoSiguiente.setHeight(cntSiguiente.height());
  //textoSiguiente.setLocation();


  //{Se diseña el Boton Siguiente de la Imagen}
   //cntInformar.addChild(Cont_Span);

   //cntInformar.addChild(fondo_Sig);
   //fondo_Sig.addChild(imgSiguiente);
  // fondo_Sig.addChild(cntSiguiente);

  cntInformar.addChild(imgSiguiente);
 // cntInformar.addChild(cntSiguiente);
;
  
  cajaSecundaria.addChild(cntInformar);
  cajaSecundaria.addChild(Imagen);
  /*Eventos Importantes Para pasar al Siguiente Imagen*/
  imgSiguiente.eventAddListener('single-tap', function(){
    cajaSecundaria.removeChild(cntInformar);
    cajaSecundaria.removeChild(Imagen);
    if(i<URLImagenes.length){
          mostrarImgEInformacion(id, URLImagenes[i+1], DataMostrar[i+1], cajaSecundaria, imgAmerica, i+1);
    }else{
      crearSegundo('Segunda',  cajaSecundaria);
    }
  });
  /*Regresar a un escenario Anterior */
  regresarText.eventAddListener('single-tap',function(){
    Imagen.setVisible(false);
    cntInformar.setVisible(false);
    crearSegundo('Segunda Pantalla', cajaSecundaria)
    //CrearTercerEscenario(imgAmerica.width(),imgAmerica.height(), id, imgAmerica, cajaSecundaria);
    //callScene(cajaSecundaria, imgAmerica,'SegundaEscena');
  });
  /*Agrandece la imagen*/ 
  zoom.eventAddListener('single-tap', function(){
      /*Ocultar icons*/
  regresarText.setVisible(false);
  text_zoom.setVisible(false);
  regresar.setVisible(false);
  zoom.setVisible(false);
  /*--Ocultar texto---*/
  cntInformar.setVisible(false);
  /*---*/ 
     Imagen.setWidth(imgAmerica.width()-30);
   Imagen.setHeight(imgAmerica.height());
   Imagen.setLocation(0,0);
   exit.setVisible(true);
  });
  /*Regresa la imagen A su estado anterior*/
  exit.eventAddListener('single-tap', function(){
       Imagen.setLocation(0,0);
     Imagen.setWidth(imgAmerica.width()-30);
     Imagen.setHeight((altura/3)*2);
     exit.setVisible(false);
     /*--Mostrar icons--*/
       regresarText.setVisible(true);
  text_zoom.setVisible(true);
  regresar.setVisible(true);
  zoom.setVisible(true);
  /*--Ocultar texto---*/
  cntInformar.setVisible(true);
  });
}


/*Funcion de Operator Esta funcion funciona en tiempo real, 
  si  quiere mover un widget al lado derecho solo llama a esta funcion con 
  con la propiedad del <nombreWidget>.addOperator(<nombreFuncion>())
*/

k=0;
function create( posicionY, direccion) {
  var o = new MultiWidgets.JavaScriptOperator();

  o.onUpdate(function(w, frameInfo) {
    k++;
    if(direccion=='derecha'){

      w.setLocation(new Nimble.Vector2f(posicionY,k));
    }
    if(direccion=='izquierda'){
      w.setLocation(new Nimble.Vector2f(posicionY,-k));
    }

      if(k==900){
      k=0;
      k--;
    }
    this.setVelocity(0.05);

  });

  o.reset();

  return o;
}


/*Cosas a realizar

1.- regresar a la pantalla 3,

3.- Poner el slider*/