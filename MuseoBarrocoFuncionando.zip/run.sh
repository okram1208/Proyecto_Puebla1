#!/bin/bash

source `dirname "$0"`/../common.sh Museo.js $@
